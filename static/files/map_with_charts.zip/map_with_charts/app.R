#THIS IS A DEMO APP FOR SHOWING SENTIMENTS AND MAP IN TWEETS

library(shiny)
library(rCharts)
library(lubridate)
library(highcharter)

# UI
ui <- fluidPage(
  
  # Application title
  titlePanel("Your app title"),
  
  p(
    class = "text-muted",
    paste("Demo: you can enter text here."
    )
  ),
    
  
  sidebarLayout(
    sidebarPanel(        
      helpText(h5("based on sentiment type", style = "font-family: 'arial'; font-si12pt")),
      checkboxGroupInput("type", 
                         label = (helpText(h5("sentiment type"))),
                         
                         choices = list("anger" = "anger", 
                                        "anticipation" = "anticipation", 
                                        "disgust" = "disgust", 
                                        "fear" = "fear",
                                        "joy" = "joy",
                                        "sadness" = "sadness",
                                        "surprise"="surprise",
                                        "trust"="trust"),
                         selected = "trust"),
      
      sliderInput("slider1", h3("min. retweet count"),
                  min = 0, max = 100, value = 1),
      
      p(
        class = "text-muted",
        paste("Demo: you can enter text here."
        )
      )
      
      ),
    
    
    mainPanel(
      highchartOutput("chart1",height = "500px"),

      leafletOutput("mymap"),
      p(class = "text-muted",paste("Demo: you can enter text here.")
      )
    )
  )
)

# SERVER 
server <- function(input, output) {
  
  senti_data <- read.csv("senti_aggregated.csv", header = TRUE)
  
  geocodes <- read.csv("geocodes.csv", header = TRUE)
  
  senti_data$day <- as.Date(senti_data$day)
  
  output$chart1 <- renderHighchart({
    
    highchart() %>%
      hc_add_series(data=  senti_data[senti_data$variable %in% input$type,],"line", hcaes(x = day, y = value, group=variable)) %>%
      hc_xAxis(type = "datetime")
  })
  
  output$mymap <- renderLeaflet({
    
    usericon <- makeIcon(
      iconUrl = geocodes$profile_image_url,
      iconWidth = 15, iconHeight = 15
    )
    
    
    leaflet(data = geocodes[geocodes$retweet_count >= input$slider1,]) %>% 
      addTiles() %>%
      setView(lng = -98.35, lat = 39.50, zoom = 2) %>% 
      addMarkers(lng = ~lng, lat = ~lat,popup = ~ as.character(text),icon = usericon) %>% 
      addProviderTiles("Stamen.TonerLite") %>%  #more layers:http://leaflet-extras.github.io/leaflet-providers/preview/
      addCircleMarkers(
        stroke = FALSE, fillOpacity = 0.5)
  })
    
}

# Run the application 
shinyApp(ui = ui, server = server)

