library(rtweet)
library(leaflet)

# COLLECT TWEETS
mytoken <- create_token(
  app = "", #app name here
  consumer_key = "", #consumer key here
  consumer_secret = "", #consumer secret here
  access_token = "", #access token here
  access_secret = "") #access secret here

tweets <- search_tweets("", n = 10000, token=mytoken) 

# GET GEO CODES
geocodes <- lat_lng(tweets)

geocodes <- geocodes[!is.na(geocodes$lat),] 

write_as_csv(geocodes,"geocodes.csv") #don't forget to copy this saved file to your app directory

#GET SENTIMENTS FROM TWEETS
#standardize timestamps
partytweets$created_at <- ymd_hms(partytweets$created_at) 
partytweets$created_at <- with_tz(partytweets$created_at,"America/New_York")
partytweets$created_date <- as.Date(partytweets$created_at)

#create a factor column for dates; used for groupping in later steps
partytweets$date_label <- as.factor(partytweets$created_date)

#clean the text
partytweets$clean_text <- str_replace_all(partytweets$text, "@\\w+", "")

#extract sentiments
Sentiment <- get_nrc_sentiment(partytweets$clean_text)

#combine the data frame containing sentiment scores and the original data frame containing tweets and other Twitter metadata
alltweets_senti <- cbind(partytweets, Sentiment)

#aggregate the data by dates and screennames
senti_aggregated <- alltweets_senti %>% 
  group_by(date_label,screen_name) %>%
  summarise(anger = mean(anger), 
            anticipation = mean(anticipation), 
            disgust = mean(disgust), 
            fear = mean(fear), 
            joy = mean(joy), 
            sadness = mean(sadness), 
            surprise = mean(surprise), 
            trust = mean(trust)) %>% melt

senti_aggregated$day <- as.Date(senti_aggregated$date_label)

write_as_csv(senti_aggregated, "senti_aggregated.csv")